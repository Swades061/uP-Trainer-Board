#ifndef DOT_MATRIX_CFG_H_
#define DOT_MATRIX_CFG_H_

#include "DOT_MATRIX.h"

extern const DOT_MATRIX_CfgType DOT_MATRIX_CfgParam[DOT_MATRIX_UNITS];

#endif /* DOT_MATRIX_CFG_H_ */
