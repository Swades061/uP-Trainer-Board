#include "DOT_MATRIX.h"

const DOT_MATRIX_CfgType DOT_MATRIX_CfgParam[DOT_MATRIX_UNITS] =
{
	// DOT_MATRIX Display Unit1 Configurations
    {
		GPIOC,
		GPIO_PIN_11,
		75,   /* Scroll Speed*/
		1,    /* Number Of Cascaded Devices,2 when scroll,1 when static*/
		8,    /* Brightness Level */
		SCROLL_MODE //SCROLL_MODE-scrolling;STATIC_MODE-static
	}
};
